package chess;

/**
 * This class contains the object methods for the type Board.
 * @author leona
 */
public class Board {
    private String[][]board;
    /**
     * Constructor for the board object
     */
    protected Board(){
        //Letters at the line 0 of the board
        this.board=new String[9][9];
        this.board[0][0]="  ";
        this.board[0][1]="A ";
        this.board[0][2]="B ";
        this.board[0][3]="C ";
        this.board[0][4]="D ";
        this.board[0][5]="E ";
        this.board[0][6]="F ";
        this.board[0][7]="G ";
        this.board[0][8]="H ";
        //Numbers at column 0 of the board
        this.board[1][0]="1 ";
        this.board[2][0]="2 ";
        this.board[3][0]="3 ";
        this.board[4][0]="4 ";
        this.board[5][0]="5 ";
        this.board[6][0]="6 ";
        this.board[7][0]="7 ";
        this.board[8][0]="8 ";
        //Markers for black and white positions
        for(int i=1;i<9;i++){
            for(int j=1;j<9;j++){
                if(i%2!=0){
                    if(j%2==0){
                        board[i][j]="* ";
                    }else{
                        board[i][j]="  ";
                    }
                }else{
                    if(j%2==0){
                        board[i][j]="  ";
                    }else{
                        board[i][j]="* ";
                    }
                }
            }
        }
        //Pawns for player 1
        this.board[1][1]="TB";
        this.board[2][1]="CB";
        this.board[3][1]="AB";
        this.board[4][1]="KB";
        this.board[5][1]="QB";
        this.board[6][1]="AB";
        this.board[7][1]="CB";
        this.board[8][1]="TB";
        this.board[1][2]="PB";
        this.board[2][2]="PB";
        this.board[3][2]="PB";
        this.board[4][2]="PB";
        this.board[5][2]="PB";
        this.board[6][2]="PB";
        this.board[7][2]="PB";
        this.board[8][2]="PB";
        //Pawns for player 2
        this.board[1][8]="TN";
        this.board[2][8]="CN";
        this.board[3][8]="AN";
        this.board[4][8]="KN";
        this.board[5][8]="QN";
        this.board[6][8]="AN";
        this.board[7][8]="CN";
        this.board[8][8]="TN";
        this.board[1][7]="PN";
        this.board[2][7]="PN";
        this.board[3][7]="PN";
        this.board[4][7]="PN";
        this.board[5][7]="PN";
        this.board[6][7]="PN";
        this.board[7][7]="PN";
        this.board[8][7]="PN";
    }
    /**
     * Method still to do.
     * @param save
     * @return 
     */
    private Board importBoard(String save){
        return new Board();
    }
    /**
     * This method prints the board.
     */
    protected void print(){
        for(int i=0;i<9;i++){
            for(int j=0;j<9;j++){
                System.out.print(this.board[i][j]+" ");
            }
            System.out.println("");
        }
    }
    /**
     * This method moves the x, y pawn to x_move, y_move.
     * @param x move from this x
     * @param y move from this y
     * @param x_move move to this x
     * @param y_move move to this y
     */
    protected void movePawn(int x, int y, int x_move, int y_move){
        this.board[y_move][x_move]=this.board[y][x];
    }
    /**
     * This method returns the pawn at that specific place.
     * @param x
     * @param y
     * @return 
     */
    protected String getPawn(int x, int y){
        return this.board[y][x];
    }
    protected String[][] getBoard(){
        return this.board;
    }
    protected void fillPos(int x,int y){
        if(x%2!=0){
            if(y%2==0){
                this.board[y][x]="* ";
            }else{
                this.board[y][x]="  ";
            }
        }else{
            if(y%2==0){
                this.board[y][x]="  ";
            }else{
                this.board[y][x]="* ";
            }
        }
    }
    protected boolean gameOver(){
        int c_queens=0;
        for(int i=0;i<9;i++){
            for(int j=0;j<9;j++){
                if(board[i][j].equals("QB")||board[i][j].equals("QN")){
                    c_queens++;
                }
            }
        }
        if(c_queens<2){
            return true;
        }else{
            return false;
        }
    }
    public boolean verifySel(int lastPlayer,int x,int y){
        //This method identifies if the pawn is ready to eat
        if(lastPlayer==1){
            switch(this.board[y][x]){
                case "PN":
                    return true;
                case "CN":
                    return true;
                case "AN":
                    return true;
                case "TN":
                    return true;
                case "KN":
                    return true;
                case "QN":
                    return true;
                default:
                    return false;
            }
        }else if(lastPlayer==2){
            switch(this.board[y][x]){
                case "PB":
                    return true;
                case "CB":
                    return true;
                case "AB":
                    return true;
                case "TB":
                    return true;
                case "KB":
                    return true;
                case "QB":
                    return true;
                default:
                    return false;
            }
        }
        //Else case here because return exits the method already
        return false;
    }
    public boolean canEat(int x_move,int y_move){
        //This methods identifies if the pawn is ready to eat
        if(this.board[y_move][x_move].charAt(0)=='*'||this.board[y_move][x_move].charAt(0)==' '){
            return false;
        }else{
            return true;
        }
    }
    public String pawnIdentifier(int x,int y){
        //This method identifies the type of the pawn to eat
        switch(this.board[y][x]){
            case "TB":
                return "Torre";
            case "PB":
                return "Pedone";
            case "KB":
                return "Re";
            case "QB":
                return "Regina";
            case "AB":
                return "Alfiere";
            case "CB":
                return "Cavallo";
            case "TN":
                return "Torre";
            case "PN":
                return "Pedone";
            case "KN":
                return "Re";
            case "QN":
                return "Regina";
            case "AN":
                return "Alfiere";
            case "CN":
                return "Cavallo";
            default:
                throw new ArrayIndexOutOfBoundsException("NON ESISTE UNA PEDINA VALIDA A "+x+", "+y+"!");
        }
    }
    public boolean movementVerifier(int lastPlayer,String pawnType,int x,int y,int x_move,int y_move){
        switch(pawnType){
            case "Pedone":
                if(lastPlayer==1){
                    if((y_move-y!=0&&(this.board[y+1][x].charAt(0)!='*'||this.board[y+1][x].charAt(0)!=' '||this.board[y-1][x].charAt(0)!='*'||this.board[y-1][x].charAt(0)!=' '))||x_move-x!=1){
                        return false;
                    }else{
                        return true;
                    }
                }else{
                    if(this.board[y][x].equals("PB")){
                        return false;
                    }
                    if(y-y_move!=0||x-x_move!=1){
                        return false;
                    }else{
                        return true;
                    }
                }
            case "Torre":
                break;
            case "Re":
                break;
            case "Regina":
                break;
            case "Alfiere":
                break;
            case "Cavallo":
                break;
            default:
                throw new ArrayIndexOutOfBoundsException("MOVIMENTO NON VALIDO DA "+x+", "+y+" A "+x_move+", "+y_move+"!");
        }
        return false;
    }
}