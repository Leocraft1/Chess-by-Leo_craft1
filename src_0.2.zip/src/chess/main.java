package chess;
import java.util.Scanner;

//@author leona
public class main {
    public static void main(String[]args) {
        //Game starts
        //Console clearing disabled due to visual bugs
        //System.out.print("\033[H\033[2J");
        //printMenu() prints the menu and takes the input of the menu
        switch(printMenu()){
            case 1:
                Board board=new Board();
                game(board);
                break;
            case 2:
                System.out.println("Funzione non ancora disponibile.");
                break;
            case 3:
                System.out.println("Uscito dal gioco.");
                break;
        }
    }
    public static void game(Board board){
        //COUNTER DECLARATION
        int i,j,y,x,y_move,x_move,c_queens=0,lastPlayer;
        boolean invalidSelection=false,readyToEat=false,gameEnded=false;
        String letterx,pawnType,tmp;
        Scanner keyb=new Scanner(System.in);
        //This method contains the actual game.
        //Printing the chess board
        board.print();
        //Asking for a pawn to move
        do{
            do{
                do{
                    invalidSelection=false;
                    System.out.println("Giocatore 1: ");
                    lastPlayer=1;
                    System.out.print("Riga della pedina da muovere: ");
                    do{
                        y=keyb.nextInt();
                        if(y<1||y>8){
                            System.out.print("E' fuori dalla scacchiera! Reinserisci: ");
                        }
                    }while(y<1||y>8);
                    keyb.nextLine();
                    System.out.print("Colonna della pedina da muovere: ");
                    do{
                        letterx=keyb.nextLine();
                        if(letterx.isBlank()){
                            System.out.print("Non hai inserito niente: ");
                        }else if(letterx.length()>1){
                            System.out.print("Hai inserito piu' di un carattere: ");
                        }else if(letterx.toUpperCase().charAt(0)<65||letterx.toUpperCase().charAt(0)>72){
                            System.out.print("E' fuori dalla scacchiera! Reinserisci: ");
                        }
                    }while(letterx.isBlank()||letterx.length()>1||letterx.toUpperCase().charAt(0)<65||letterx.toUpperCase().charAt(0)>72);
                    x=letterxtoint(letterx);
                    //Verify if the selection is empty or not
                    if(board.verifySel(lastPlayer,x,y)){
                        System.out.println("Alla posizione "+letterx+" "+y+" non c'e' nessuna pedina, o non è tua.");
                        board.print();
                    }
                }while(board.verifySel(lastPlayer,x,y));
                //Resets invalidSelection
                invalidSelection=false;
                //Asking where to move it
                System.out.print("Riga della casella dove vuoi spostare la pedina: ");
                do{
                    y_move=keyb.nextInt();
                    if(y_move<1||y_move>8){
                        System.out.print("E' fuori dalla scacchiera! Reinserisci: ");
                    }
                }while(y_move<1||y_move>8);
                keyb.nextLine();
                System.out.print("Colonna della casella dove vuoi spostare la pedina: ");
                do{
                    letterx=keyb.nextLine();
                    if(letterx.isBlank()){
                        System.out.print("Non hai inserito niente: ");
                    }else if(letterx.length()>1){
                        System.out.print("Hai inserito piu' di un carattere: ");
                    }else if(letterx.toUpperCase().charAt(0)<65||letterx.toUpperCase().charAt(0)>72){
                        System.out.print("E' fuori dalla scacchiera! Reinserisci: ");
                    }
                }while(letterx.isBlank()||letterx.length()>1||letterx.toUpperCase().charAt(0)<65||letterx.toUpperCase().charAt(0)>72);
                x_move=letterxtoint(letterx);
                //Verify if the player can do this movement
                pawnType=board.pawnIdentifier(x,y);
                if(!board.movementVerifier(lastPlayer,pawnType,x,y,x_move,y_move)){
                    invalidSelection=true;
                    System.out.println("Non puoi muoverlo li");
                }
            }while(invalidSelection);
            invalidSelection=false;
            //Verify if the destination already has a pawn and can eat it
            if(board.canEat(x_move,y_move)){
                pawnType=board.pawnIdentifier(x_move,y_move);
                System.out.print("Alla posizione "+letterx+" "+y_move+" c'è un "+pawnType+"; vuoi mangiarlo? [y=yes/n=no]: ");
                do{
                    invalidSelection=false;
                    tmp=keyb.nextLine();
                    if(tmp.isBlank()){
                        System.out.print("Non hai inserito niente [y=yes/n=no]: ");
                        invalidSelection=true;
                    }else if(tmp.length()>1){
                        System.out.print("Hai inserito piu' di un carattere [y=yes/n=no]: ");
                        invalidSelection=true;
                    }else if(tmp.charAt(0)!='y'&&tmp.charAt(0)!='n'){
                        System.out.print(tmp+" non e' un'opzione valida [y=yes/n=no]: ");
                        invalidSelection=true;
                    }
                }while(invalidSelection);
            }
            //Moving the pawn
            board.movePawn(x,y,x_move,y_move);
            //Filling the empty space with * or space
            board.fillPos(x,y);
            //Printing the chess board
            board.print();
            //Verifying if the game is over
            if(board.gameOver()){
                System.out.println("Game Over!");
                System.out.println("Ha vinto il Giocatore 1");
            }
            //Player 2
            if(!gameEnded){
                do{
                    do{
                        invalidSelection=false;
                        System.out.println("Giocatore 2: ");
                        lastPlayer=2;
                        System.out.print("Riga della pedina da muovere: ");
                        do{
                            y=keyb.nextInt();
                            if(y<1||y>8){
                                System.out.print("E' fuori dalla scacchiera! Reinserisci: ");
                            }
                        }while(y<1||y>8);
                        keyb.nextLine();
                        System.out.print("Colonna della pedina da muovere: ");
                        do{
                            letterx=keyb.nextLine();
                            if(letterx.isBlank()){
                                System.out.print("Non hai inserito niente: ");
                            }else if(letterx.length()>1){
                                System.out.print("Hai inserito piu' di un carattere: ");
                            }else if(letterx.toUpperCase().charAt(0)<65||letterx.toUpperCase().charAt(0)>72){
                                System.out.print("E' fuori dalla scacchiera! Reinserisci: ");
                            }
                        }while(letterx.isBlank()||letterx.length()>1||letterx.toUpperCase().charAt(0)<65||letterx.toUpperCase().charAt(0)>72);
                        x=letterxtoint(letterx);
                        //Verify if the selection is empty or not
                        if(board.verifySel(lastPlayer,x,y)){
                            System.out.println("Alla posizione "+letterx+" "+y+" non c'e' nessuna pedina, o non è tua.");
                            board.print();
                        }
                    }while(board.verifySel(lastPlayer,x,y));
                    //Resets invalidSelection
                    invalidSelection=false;
                    //Asking where to move it
                    System.out.print("Riga della casella dove vuoi spostare la pedina: ");
                    do{
                        y_move=keyb.nextInt();
                        if(y_move<1||y_move>8){
                            System.out.print("E' fuori dalla scacchiera! Reinserisci: ");
                        }
                    }while(y_move<1||y_move>8);
                    keyb.nextLine();
                    System.out.print("Colonna della casella dove vuoi spostare la pedina: ");
                    do{
                        letterx=keyb.nextLine();
                        if(letterx.isBlank()){
                            System.out.print("Non hai inserito niente: ");
                        }else if(letterx.length()>1){
                            System.out.print("Hai inserito piu' di un carattere: ");
                        }else if(letterx.toUpperCase().charAt(0)<65||letterx.toUpperCase().charAt(0)>72){
                            System.out.print("E' fuori dalla scacchiera! Reinserisci: ");
                        }
                    }while(letterx.isBlank()||letterx.length()>1||letterx.toUpperCase().charAt(0)<65||letterx.toUpperCase().charAt(0)>72);
                    x_move=letterxtoint(letterx);
                    //Verify if the player can do this movement
                    pawnType=board.pawnIdentifier(x,y);
                    if(!board.movementVerifier(lastPlayer,pawnType,x,y,x_move,y_move)){
                        invalidSelection=true;
                        System.out.println("Non puoi muoverlo li");
                    }
                }while(invalidSelection);
                invalidSelection=false;
                //Verify if the destination already has a pawn and can eat it
                if(board.canEat(x_move,y_move)){
                    pawnType=board.pawnIdentifier(x_move,y_move);
                    System.out.print("Alla posizione "+letterx+" "+y_move+" c'è un "+pawnType+"; vuoi mangiarlo? [y=yes/n=no]: ");
                    do{
                        invalidSelection=false;
                        tmp=keyb.nextLine();
                        if(tmp.isBlank()){
                            System.out.print("Non hai inserito niente [y=yes/n=no]: ");
                            invalidSelection=true;
                        }else if(tmp.length()>1){
                            System.out.print("Hai inserito piu' di un carattere [y=yes/n=no]: ");
                            invalidSelection=true;
                        }else if(tmp.charAt(0)!='y'&&tmp.charAt(0)!='n'){
                            System.out.print(tmp+" non e' un'opzione valida [y=yes/n=no]: ");
                            invalidSelection=true;
                        }
                    }while(invalidSelection);
                }
                //Moving the pawn
                board.movePawn(x,y,x_move,y_move);
                //Filling the empty space with * or space
                board.fillPos(x,y);
                //Printing the chess board
                board.print();
                //Verifying if the game is over
                if(board.gameOver()){
                    System.out.println("Game Over!");
                    System.out.println("Ha vinto il Giocatore 1");
                }
            }
        }while(!gameEnded);
        //Game ended.
    }
    public static int letterxtoint(String letterx){
        int x;
        switch(letterx.toUpperCase().charAt(0)){
            case 'A':
                x=1;
                break;
            case 'B':
                x=2;
                break;
            case 'C':
                x=3;
                break;
            case 'D':
                x=4;
                break;
            case 'E':
                x=5;
                break;
            case 'F':
                x=6;
                break;
            case 'G':
                x=7;
                break;
            case 'H':
                x=8;
                break;
            default:
                throw new ArrayIndexOutOfBoundsException("COLONNA NON VALIDA A "+letterx+"!");
        }
        return x;
    }
    /**
     * This method is used for checking if the pawn selection is valid
     * @param lastPlayer
     * @param y
     * @param x
     * @param board
     * @return true if the selection is invalid
     */
    
    /**
     * This method verifies if the movement is valid.
     * @param lastPlayer
     * @param board
     * @param pawnType
     * @param x
     * @param y
     * @param x_move
     * @param y_move
     * @return 
     */
    
    /**
     * Prints the menu and returns the selection.
     * @return int value, the selection, can only be 1 2 or 3, other options are considered invalid.
     */
    public static int printMenu(){
        int menuSelector;
        boolean invalidSelector=false;
        Scanner keyb=new Scanner(System.in);
        System.out.println("============================================================================================================");
        System.out.println("E' tempo di scacchi!");
        System.out.println("Il gioco e' disponibile solo in italiano.");
        System.out.println("The game is only available in italian.");
        System.out.println("1. Nuova Partita");
        System.out.println("2. Carica Salvataggio");
        System.out.println("3. Esci dal gioco");
        System.out.println("============================================================================================================");
        System.out.print("Inserire la scelta: ");
        do{
            menuSelector=keyb.nextInt();
            if(menuSelector!=1&&menuSelector!=2&&menuSelector!=3){
                System.out.print(menuSelector+" non e' una scelta valida: ");
                invalidSelector=true;
            }
        }while(invalidSelector);
        return menuSelector;
    }
}